'use strict';

import React, { Component } from 'react';

import {
  StyleSheet,
  View,
  ScrollView,
  Text,
  Image
} from 'react-native';

class ScrollViewScreen extends Component {
  static navigationOptions = {
    title: 'This is scrollView'
  }
  render() {
    return (
      <View>
        <ScrollView>
          <Text style={{fontSize:48}}>Scroll me plz</Text>
          <Image source={require('../assets/50.png')} />
          <Image source={require('../assets/50.png')} />
          <Image source={require('../assets/50.png')} />
          <Image source={require('../assets/50.png')} />
          <Image source={require('../assets/50.png')} />
          <Text style={{fontSize:48}}>If you like</Text>
          <Image source={require('../assets/50.png')} />
          <Image source={require('../assets/50.png')} />
          <Image source={require('../assets/50.png')} />
          <Image source={require('../assets/50.png')} />
          <Image source={require('../assets/50.png')} />
          <Text style={{fontSize:48}}>Scrolling down</Text>
          <Image source={require('../assets/50.png')} />
          <Image source={require('../assets/50.png')} />
          <Image source={require('../assets/50.png')} />
          <Image source={require('../assets/50.png')} />
          <Image source={require('../assets/50.png')} />
          <Text style={{fontSize:48}}>What's the best</Text>
          <Image source={require('../assets/50.png')} />
          <Image source={require('../assets/50.png')} />
          <Image source={require('../assets/50.png')} />
          <Image source={require('../assets/50.png')} />
          <Image source={require('../assets/50.png')} />
          <Text style={{fontSize:48}}>Framework around?</Text>
          <Image source={require('../assets/50.png')} />
          <Image source={require('../assets/50.png')} />
          <Image source={require('../assets/50.png')} />
          <Image source={require('../assets/50.png')} />
          <Image source={require('../assets/50.png')} />
          <Text style={{fontSize:48}}>React Native</Text>
        </ScrollView>
      </View>
    );
  }
}

const styles = StyleSheet.create({

});


export default ScrollViewScreen;