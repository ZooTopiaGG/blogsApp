'use strict';

import React, { Component } from 'react';

import {
  StyleSheet,
  View,
  Text
} from 'react-native';

class toNone extends Component {
  render() {
    return (
      <View>
        <Text>哈哈哈哈哈哈哈哈哈 { this.props.state.params.mode }</Text>
      </View>
    );
  }
}

const styles = StyleSheet.create({

});


export default toNone;