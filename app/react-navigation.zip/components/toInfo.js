'use strict';

import React, { Component } from 'react';

import {
  StyleSheet,
  View,
  Text
} from 'react-native';

class toInfo extends React.Component {
  render() {
    return (
      <View>
        <Text>嘿嘿嘿恶黑恶黑恶黑恶虎{ this.props.state.params.mode }</Text>
      </View>
    );
  }
}

const styles = StyleSheet.create({

});


export default toInfo;