'use strict';

import React, { Component } from 'react';

import {
  StyleSheet,
  View,
  Button,
  Text
} from 'react-native';

import ToNone from './toNone.js'
import ToInfo from './toInfo.js'

class InfoAndNoneScreen extends React.Component{
  static navigationOptions = ({ navigation, screenProps }) => {
    const { state, setParams } = navigation
    const isInfo = state.params.mode === 'info'
    const { user } = state.params
    return {
      title: isInfo ? `${user} Contact info`: `Chat with ${state.params.user} `,
      headerRight:(
        <Button 
          title={ isInfo ? 'Done':`${state.params.user} info` }
          onPress={ () => setParams({ mode: isInfo ? 'none' : 'info' })}
        />
      )
    }
  }
  render() {
    const { state  } = this.props.navigation
    if (state.params.mode === 'info') {
      return (
        <View>
          <View style={{ marginTop: 20 }}>
            <ToNone state={ state }/>
          </View>
        </View>
      );
    }else{
      return (
        <View>
          <View style={{ marginTop: 20 }}>
            <ToInfo state={ state }/>
          </View>
        </View>
      );
    }
  }
}

export default InfoAndNoneScreen;