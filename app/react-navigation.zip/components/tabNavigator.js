'use strict';

import React, { Component } from 'react';

import {
  StyleSheet,
  View,
  Text
} from 'react-native';

import { TabNavigator } from 'react-navigation'

// class TabNavigatorScreen extends Component {
//   render() {
//     return (
//       <View />
//     );
//   }
// }

class RecentChatsScreen extends React.Component {
  render() {
    return <Text>List of recent chats</Text>
  }
}

class AllContactsScreen extends React.Component {
  render() {
    return <Text>List of all contacts</Text>
  }
}

const TabNavigatorScreen = TabNavigator({
  Recent: { 
    screen: RecentChatsScreen,
    navigationOptions: {
      title: 'My Chats',
    },
  },
  All: { 
    screen: AllContactsScreen,
    navigationOptions: {
      title: 'Your Chats',
    },
  },
});


export default TabNavigatorScreen;