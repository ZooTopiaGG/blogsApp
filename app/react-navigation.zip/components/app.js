'use strict';

import React from 'react';
import {
  Platform,
  AppRegistry,
  Text,
  Button,
  View
} from 'react-native';

// const instructions = Platform.select({
//   ios: 'Press Cmd+R to reload,\n' +
//     'Cmd+D or shake for dev menu',
//   android: 'Double tap R on your keyboard to reload,\n' +
//     'Shake or press menu button for dev menu',
// });

import { StackNavigator } from 'react-navigation';
import NavigatorScreen from './navgaitor.js'
import HomeScreen from './home.js'
import FlexScreen from './flex.js'
import ScrollViewScreen from './scrollView.js'
import FlatListScreen from './flatList.js'
import FetchScreen from './fetch.js'
import IntervalScreen from './interval.js'
import SetNativePropsScreen from './setNativeProps.js'
import TabNavigatorScreen from './tabNavigator.js'
import InfoAndNoneScreen from './infoAndNone.js'

const MyBlogApp = StackNavigator({
  Home: { screen: HomeScreen },
  Navigator: { screen: NavigatorScreen },
  Flex: { screen: FlexScreen },
  ScrollView: { screen: ScrollViewScreen },
  FlatList: { screen: FlatListScreen },
  Fetch: { screen: FetchScreen },
  Interval: { screen: IntervalScreen },
  SetNativeProps: { screen:SetNativePropsScreen },
  TabNavigator: { screen:TabNavigatorScreen },
  InfoAndNone: { screen:InfoAndNoneScreen }
})

export default MyBlogApp
