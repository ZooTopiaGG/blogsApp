'use strict';

import React, { Component } from 'react';

import {
  StyleSheet,
  View,
  Text
} from 'react-native';

class flexScreen extends React.Component {
  static navigationOptions = {
    title: 'This is Flex'
  }
  render() {
    return (
      <View style={styles.container} >
        <Text style={styles.flexTitle}>我是flexScreen</Text>
      </View>
    );
  }
}
// flex:1 使view 充满整个盒子
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor:"#000",
    paddingTop:20
  },
  flexTitle: {
    color:'#fff',
    fontSize:48,
    marginTop:20
  },
});

export default flexScreen;