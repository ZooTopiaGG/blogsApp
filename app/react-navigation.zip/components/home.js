'use strict';

import React, { Component } from 'react';

import {
  StyleSheet,
  View,
  Text,
  Button,
  ScrollView
} from 'react-native';

class HomeScreen extends React.Component {
  static navigationOptions = {
    title: 'Welcome',
  };
  render() {
    const { navigate } = this.props.navigation
    return (
      <ScrollView>
        <Text style={{ marginBottom: 20, marginTop:20 }}>Hello, Navigation!</Text>
        <View style={{ marginBottom: 20 }}>
          <Button
            onPress={() => navigate('Navigator', { admin: '邓鹏' })}
            title="Navigator with 邓鹏"
          />
        </View>
        <View style={{ marginBottom: 20 }}>
          <Button
            onPress={() => navigate('Flex')}
            title="Flex with 邓鹏"
          />
        </View>
        <View style={{ marginBottom: 20 }}>
          <Button
            onPress={() => navigate('ScrollView')}
            title="ScrollView with 邓鹏"
          />
        </View>
        <View style={{ marginBottom: 20 }}>
          <Button
            onPress={() => navigate('FlatList')}
            title="FlatList with 邓鹏"
          />
        </View>
        <View style={{ marginBottom: 20 }}>
          <Button
            onPress={() => navigate('Fetch')}
            title="Fetch with 邓鹏"
          />
        </View>
        <View style={{ marginBottom: 20 }}>
          <Button
            onPress={() => navigate('Interval')}
            title="Interval with 邓鹏"
          />
        </View>
        <View style={{ marginBottom: 20 }}>
          <Button
            onPress={() => navigate('SetNativeProps')}
            title="SetNativeProps with 邓鹏"
          />
        </View>
        <View style={{ marginBottom: 20 }}>
          <Button
            onPress={() => navigate('TabNavigator')}
            title="TabNavigator with 邓鹏"
          />
        </View>
        <View style={{ marginBottom: 20 }}>
          <Button
            onPress={() => navigate('InfoAndNone', { user: 'Lucy`s' , mode: 'info'})}
            title="InfoAndNone with 邓鹏"
          />
        </View>
      </ScrollView>
    );
  }
}


export default HomeScreen;