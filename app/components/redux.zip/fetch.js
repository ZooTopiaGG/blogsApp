'use strict';

import React, { Component } from 'react';

import {
  StyleSheet,
  View,
  Button,
  Image,
  Text,
  ScrollView
} from 'react-native';

class FetchScreen extends Component {
  constructor(props) {
    super(props);
  
    this.state = {
      title: '',
      name: ''
    };
  }
  static navigationOptions = {
    title: 'This is FetchScreen',
    rightButtonTitle:'分享'
  }
  getPromiseRequest () {
    // 返回一个Promise 对象
    return fetch('http://pay.lawyer-says.cn/shareToListen/get_info', {
      method:'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        id: 309
      })
    })
    .then((response) => {
      return response.json()
    })
    .then((responseJson) => {
      alert(responseJson+'promise')
      this.setState((resultState) => {
        return {
          title : responseJson.result.description,
          name: responseJson.result.lawyer_name
        }
      })
      // return responseJson
    })
    .catch((error) => {
      console.error(error);
    });
  }
  componentDidMount() {
    // this.getPromiseRequest()
    this.getAsyncRequest()
  }
  // async await 异步操作 
  async getAsyncRequest () {
    try {
      // 注意这里的await语句，其所在的函数必须有async关键字声明
      let response = await fetch('http://pay.lawyer-says.cn/shareToListen/get_info', {
        method: 'POST',
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          id: 309
        })
      })
      let responseJson = await response.json();
      this.setState((resultState) => {
        return {
          title : responseJson.result.description,
          name: responseJson.result.lawyer_name
        }
      })
      // return responseJson
    } catch(error) {
      console.error(error)
    }
  }
  render() {
    return (
     <View style={{ flex:1 }}>
        <ScrollView>
          <View style={{ marginTop:20 }}>
            <Button 
              title='获取数据getPromiseRequest'
              onPress={this.getPromiseRequest.bind(this)}
              color='#1675e1'
            />
          </View>
           <View style={{ marginTop:20 }}>
            <Button 
              title='获取数据getAsyncRequest'
              onPress={this.getAsyncRequest.bind(this)}
              color='#1675e1'
            />
          </View>
          <View style={styles.info}>
              <Text style={{ marginBottom: 20 }}>{this.state.name}</Text>
              <Text>{this.state.title}</Text>
          </View>
        </ScrollView>
     </View>
    );
  }
}

const styles = StyleSheet.create({
  info: {
    display: 'flex',
    flexDirection: 'column'
  },
});


export default FetchScreen;