'use strict';

import React, { Component } from 'react';

import {
  StyleSheet,
  View,
  FlatList,
  Text
} from 'react-native';

class FlatListScreen extends Component {
  static navigationOptions = {
    title: 'This is FlatList'
  }
  render() {
    return (
      <View style={styles.contianer}>
        <FlatList
          data={[
            {key: 'A'},
            {key: 'B'},
            {key: 'C'},
            {key: 'D'},
            {key: 'E'},
            {key: 'F'},
            {key: 'G'},
            {key: 'H'},
            {key: 'A1'},
            {key: 'B1'},
            {key: 'C1'},
            {key: 'D1'},
            {key: 'E1'},
            {key: 'F1'},
            {key: 'G1'},
            {key: 'H1'},
          ]}
          renderItem = {
            ({item}) => {
              return <Text style={styles.item}>{item.key}</Text>
            }
          }
        />
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
   flex: 1,
   paddingTop: 22
  },
  item: {
    padding: 10,
    fontSize: 18,
    height: 44,
    borderBottomWidth:1,
    borderColor:'#999'
  },
});


export default FlatListScreen;