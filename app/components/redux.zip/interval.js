'use strict';

import React, { Component } from 'react';

import {
  StyleSheet,
  View,
  Text,
  Button
} from 'react-native';

class IntervalScreen extends Component {
  
  constructor(props) {
    super(props);
  
    this.state = {
      count: 0
    };
    // 把一个定时器挂在this 上
    this.timer = setInterval(() => {
      console.log(this.state.count)
      this.setState((preState) => {
        return {
          count: preState.count + 1
        }
      })
    }, 1000)
  }
  componentWillUnmount() {
    // 在销毁组件的时候 必须清除定时器
    // 如果存在this.timer，则使用clearTimeout清空。
    // 如果你使用多个timer，那么用多个变量，或者用个数组来保存引用，然后逐个clear
    this.timer && clearInterval(this.timer)
  }
  render() {
    return (
      <View>
          <Text>{ this.state.count }</Text>
      </View>
    );
  }
}

const styles = StyleSheet.create({

});


export default IntervalScreen;