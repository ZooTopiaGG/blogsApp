'use strict';

import React, { Component } from 'react';

import {
  StyleSheet,
  View,
  FlatList,
  Text,
  Button,
  Platform,
} from 'react-native';

export default class CustomButton extends Component {
  static navigationOptions = {
    title: 'This is FlatList'
  }
  render() {
    return (
      <View style={styles.contianer}>
        
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
   flex: 1,
   paddingTop: 22
  },
  item: {
    padding: 10,
    fontSize: 18,
    height: 44,
    borderBottomWidth:1,
    borderColor:'#999'
  },
});