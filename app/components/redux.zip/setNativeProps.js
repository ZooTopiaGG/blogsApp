'use strict';

import React, { Component } from 'react';

import {
  StyleSheet,
  View,
  Button,
  TouchableOpacity,
  Text,
  Image
} from 'react-native';
// import ToastJsModule from '../module.js'

// alert(ImagePicker)

class SetNativePropsScreen extends Component {
  static navigationOptions = (navigation, screenProps) => {
    return {
      title: "this is SetNativePropsScreensssssssssssssss",
      headerRight: <Image source={ require('../assets/99.png') } style={styles.rightImg}/>,
    }
  }
  constructor(props) {
    super(props);
  
    this.state = {
      count: 0,
      buttonOpacity: 1
    };
  }
  _handlePress() {
    this.setState({
      count: this.state.count + 1
    })
  }
  handlePress(value) {
   this.refs.ccc.setNativeProps({
      opacity: value
    });
  }
  _click() {
    // ToastJsModule.show('我被点击了', ToastJsModule.SHORT)
    alert(1)
  }
  render() {
    // let ent = '我被点了'+{this.state.count}+'次'
    return (
      <View>
        <TouchableOpacity
          onPress={ this._click.bind(this) } >
          <Text style={styles.button}>处理我</Text>
        </TouchableOpacity>
        <TouchableOpacity onPress={this._handlePress.bind(this)}>
          <View style={styles.button}>
            <Text style={styles.text}>我被点了{this.state.count}次</Text>
          </View>
        </TouchableOpacity>
        <Text
          ref="ccc"
          style={[ styles.button, styles.Text, { opacity: this.state.buttonOpacity } ]}
          onPress={ () => { this.setState({ buttonOpacity: 0.5 }) }}
          onPressOut={ () => { this.setState({ buttonOpacity: 1 }) } }
        >点我</Text>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  button: {
    width:200,
    height:60,
    backgroundColor: '#1675e1',
    margin:20,
    alignItems:'center',
    justifyContent: 'center',
    borderRadius:2
  },
  text: {
    fontSize:24,
    color:'#fff',
  },
  rightImg: {
    marginRight:20
  }
});
export default SetNativePropsScreen;