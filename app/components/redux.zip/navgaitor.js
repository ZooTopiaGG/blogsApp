'use strict';

import React, { Component } from 'react';

import {
  StyleSheet,
  View,
  Text
} from 'react-native';

class NavigatorScreen extends React.Component {
  // Nav options can be defined as a function of the screen's props:
  static navigationOptions = ({navigation}) => {
    return {
      title: `Chat with ${navigation.state.params.admin}`,
    }
  };
  render() {
    // The screen's current route is passed in to `props.navigation.state`
    const { params } = this.props.navigation.state;
    return (
      <View>
        <Text>Navigator with {params.admin}</Text>
      </View>
    );
  }
}

export default NavigatorScreen;